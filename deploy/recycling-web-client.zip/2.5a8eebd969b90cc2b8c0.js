(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ "./src/app/manage/base/customers-info/customer-req.model.ts":
/*!******************************************************************!*\
  !*** ./src/app/manage/base/customers-info/customer-req.model.ts ***!
  \******************************************************************/
/*! exports provided: CustomerReq, AddressReq, CollectionPeriod, ContactInfo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerReq", function() { return CustomerReq; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddressReq", function() { return AddressReq; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CollectionPeriod", function() { return CollectionPeriod; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactInfo", function() { return ContactInfo; });
var CustomerReq = /** @class */ /*@__PURE__*/ (function () {
    function CustomerReq() {
    }
    return CustomerReq;
}());

var AddressReq = /** @class */ /*@__PURE__*/ (function () {
    function AddressReq(address) {
        this.provinceCode = address.provinceCode || null;
        this.cityCode = address.cityCode || null;
        this.countyCode = address.countyCode || null;
        this.streetCode = address.streetCode || null;
        this.detailedAddress = address.detailedAddress || '';
        this.lat = address.lat || null;
        this.lng = address.lng || null;
    }
    return AddressReq;
}());

var CollectionPeriod = /** @class */ /*@__PURE__*/ (function () {
    function CollectionPeriod() {
    }
    return CollectionPeriod;
}());

var ContactInfo = /** @class */ /*@__PURE__*/ (function () {
    function ContactInfo(ci) {
        this.contactName = ci.contactName;
        this.landlinePhone = ci.landlinePhone;
        this.mobilePhone = ci.mobilePhone;
    }
    return ContactInfo;
}());




/***/ }),

/***/ "./src/app/manage/base/customers-info/customers-info.service.ts":
/*!**********************************************************************!*\
  !*** ./src/app/manage/base/customers-info/customers-info.service.ts ***!
  \**********************************************************************/
/*! exports provided: CustomersInfoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersInfoService", function() { return CustomersInfoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/index */ "./node_modules/rxjs/index.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(rxjs_index__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rebirth_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rebirth-http */ "./node_modules/rebirth-http/fesm5/rebirth-http.js");
/* harmony import */ var _customer_req_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./customer-req.model */ "./src/app/manage/base/customers-info/customer-req.model.ts");
/* harmony import */ var _shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/models/page/page-req.model */ "./src/app/shared/models/page/page-req.model.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");










var CustomersInfoService = /** @class */ /*@__PURE__*/ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(CustomersInfoService, _super);
    function CustomersInfoService(http) {
        return _super.call(this, http) || this;
    }
    CustomersInfoService.prototype.getCustomerTypes = function () {
        return null;
    };
    /**
     * 获取该收集点的所属车辆
     * @param page
     * @param params
     * @returns {null}
     */
    CustomersInfoService.prototype.getCustomerVehicles = function (page, area, state, plateNumber) {
        // TODO
        return null;
    };
    CustomersInfoService.prototype.getCustomerList = function (page, params) {
        // TODO
        return null;
    };
    /**
     * 创建收集点
     * @returns {null}
     */
    CustomersInfoService.prototype.addCustomer = function (customer) {
        return null;
    };
    /**
     * 更新收集点
     * @returns {null}
     */
    CustomersInfoService.prototype.updateCustomer = function (customer, id) {
        return null;
    };
    /**
     * 根据ID查询收运单位信息
     */
    CustomersInfoService.prototype.getCustomerById = function (id) {
        return null;
    };
    /**
     * 删除收集点
     * @returns {null}
     */
    CustomersInfoService.prototype.delCustomer = function (id) {
        return null;
    };
    CustomersInfoService.prototype.getCustomersReport = function (id) {
        return null;
    };
    CustomersInfoService.prototype.getCustomerCountsByIdAndMonth = function (id, month) {
        return null;
    };
    CustomersInfoService.prototype.getCustomerCountReport = function (id, month) {
        return null;
    };
    CustomersInfoService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_5__["defineInjectable"]({ factory: function CustomersInfoService_Factory() { return new CustomersInfoService(_angular_core__WEBPACK_IMPORTED_MODULE_5__["inject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"])); }, token: CustomersInfoService, providedIn: "root" });
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/customer-types'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", []),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "getCustomerTypes", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/vehicles'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('page')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('area')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(2, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('state')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(3, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('plateNumber')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_4__["PageReq"], String, String, String]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "getCustomerVehicles", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/customers'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('page')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('params')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_4__["PageReq"], Object]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "getCustomerList", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["POST"])('/customers'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Body"]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_customer_req_model__WEBPACK_IMPORTED_MODULE_3__["CustomerReq"]]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "addCustomer", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["PUT"])('/customers/:id'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Body"]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_customer_req_model__WEBPACK_IMPORTED_MODULE_3__["CustomerReq"], Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "updateCustomer", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/customers/:id'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "getCustomerById", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["DELETE"])('/customers/:id'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "delCustomer", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/reports/customers/:id'),
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RequestOptions"])({
            responseType: 'blob'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "getCustomersReport", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/customerCounts/:id/:month'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('month')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number, String]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "getCustomerCountsByIdAndMonth", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/customerCounts/export/:id/:month'),
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RequestOptions"])({
            responseType: 'blob'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('month')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number, String]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], CustomersInfoService.prototype, "getCustomerCountReport", null);
    return CustomersInfoService;
}(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RebirthHttp"]));




/***/ }),

/***/ "./src/app/manage/plan/models/model-converter.ts":
/*!*******************************************************!*\
  !*** ./src/app/manage/plan/models/model-converter.ts ***!
  \*******************************************************/
/*! exports provided: ModelConverter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModelConverter", function() { return ModelConverter; });
/* harmony import */ var _plan_list_model__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./plan-list.model */ "./src/app/manage/plan/models/plan-list.model.ts");
/* harmony import */ var _shared_utils_verify_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../shared/utils/verify-utils */ "./src/app/shared/utils/verify-utils.ts");
/**
 * Created by wujiahui on 2018/11/30.
 */
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s)
                if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};


var ModelConverter = /** @class */ /*@__PURE__*/ (function () {
    function ModelConverter() {
    }
    ModelConverter.planResToPlanListModel = function (r) {
        var l = new _plan_list_model__WEBPACK_IMPORTED_MODULE_0__["PlanListModel"]();
        l.id = r.id;
        l.name = r.name;
        l.numberOfRoutes = r.numberOfRoutes;
        l.numberOfTasks = r.numberOfTasks;
        l.state = r.state;
        l.category = r.category;
        l.editUser = r.editUser;
        l.createdDate = r.createdDate;
        l.checked = false;
        l.edit = false;
        return l;
    };
    // TODO
    ModelConverter.demandResToListModel = function (r) {
        var l = r;
        return l;
    };
    ModelConverter.customerResToListModel = function (r) {
        var l, collectionPeriods = null, taskList = null;
        collectionPeriods = r.collectionPeriodList.map(function (cl) {
            var period = __assign({}, cl, { vehicle: cl.plateNumber, priority: cl.priorityType });
            delete period.plateNumber;
            delete period.priorityType;
            return period;
        });
        if (r.customerList && r.customerList.length > 0) {
            taskList = r.customerList.map(function (sc) {
                return {
                    id: sc.id,
                    name: sc.name,
                    amountOfGarbage: sc.dustbin,
                    collectionPeriod: collectionPeriods,
                    checked: false,
                };
            });
        }
        // try {
        //     l = {
        //         id                : r.id,
        //         name              : r.name,
        //         collectionPeriods : collectionPeriods,
        //         collectionPeriodId: collectionPeriods[ 0 ].id,
        //         selectedPeriod    : collectionPeriods[ 0 ],
        //         amountOfGarbage   : r.dustbin,
        //         checked           : false,
        //         expand            : false,
        //         taskList          : taskList || null,
        //     };
        // } catch (e) {
        //     console.error('收运单位数据转化为收运请求数据出错::尤其检查收运时间段是否为空数组', r);
        // }
        l = {
            id: r.id,
            name: r.name,
            collectionPeriods: collectionPeriods,
            collectionPeriodId: collectionPeriods.length ? collectionPeriods[0].id : -1,
            selectedPeriod: collectionPeriods.length ? collectionPeriods[0] : undefined,
            amountOfGarbage: r.dustbin,
            checked: false,
            expand: false,
            taskList: taskList || null,
        };
        return l;
    };
    /**
     * 筛选,组装数据
     * @param l
     * @returns {DemandReq}
     */
    ModelConverter.demandListModelToReq = function (l) {
        var req;
        var amountOfGarbage = 0, taskList;
        if (_shared_utils_verify_utils__WEBPACK_IMPORTED_MODULE_1__["VerifyUtil"].isNotEmpty(l.taskList) && l.taskList.length > 0) { // 聚类请求收运量
            taskList = l.taskList
                .filter(function (sub) { return sub.checked; })
                .map(function (sub) {
                amountOfGarbage += sub.amountOfGarbage;
                return {
                    amountOfGarbage: sub.amountOfGarbage || 0,
                    customerId: sub.id,
                    name: sub.name,
                };
            });
        }
        else {
            amountOfGarbage = l.amountOfGarbage; // 普通请求收运量
        }
        req = {
            amountOfGarbage: amountOfGarbage || 0,
            collectionPeriodId: l.collectionPeriodId,
            customerId: l.id,
            name: l.name,
            taskList: taskList || null,
        };
        return req;
    };
    return ModelConverter;
}());




/***/ }),

/***/ "./src/app/manage/plan/models/plan-list.model.ts":
/*!*******************************************************!*\
  !*** ./src/app/manage/plan/models/plan-list.model.ts ***!
  \*******************************************************/
/*! exports provided: PlanListModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanListModel", function() { return PlanListModel; });
/**
 * Created by wujiahui on 2018/11/30.
 */
var PlanListModel = /** @class */ /*@__PURE__*/ (function () {
    function PlanListModel() {
    }
    return PlanListModel;
}());




/***/ }),

/***/ "./src/app/manage/plan/models/plan-req.model.ts":
/*!******************************************************!*\
  !*** ./src/app/manage/plan/models/plan-req.model.ts ***!
  \******************************************************/
/*! exports provided: PlanReq */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanReq", function() { return PlanReq; });
/**
 * Created by wujiahui on 2018/11/30.
 */
var PlanReq = /** @class */ /*@__PURE__*/ (function () {
    function PlanReq() {
    }
    return PlanReq;
}());




/***/ }),

/***/ "./src/app/manage/plan/models/plan.enum.ts":
/*!*************************************************!*\
  !*** ./src/app/manage/plan/models/plan.enum.ts ***!
  \*************************************************/
/*! exports provided: PlanCategoryEnum, PlanCategoryEnumChinese, PlanStateEnum, PlanStateEnumChinese, PlanOperationEnum */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanCategoryEnum", function() { return PlanCategoryEnum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanCategoryEnumChinese", function() { return PlanCategoryEnumChinese; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanStateEnum", function() { return PlanStateEnum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanStateEnumChinese", function() { return PlanStateEnumChinese; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanOperationEnum", function() { return PlanOperationEnum; });
/**
 * Created by wujiahui on 2018/11/30.
 */
var PlanCategoryEnum;
(function (PlanCategoryEnum) {
    PlanCategoryEnum["Formal"] = "Formal";
    PlanCategoryEnum["Demo"] = "Demo";
    PlanCategoryEnum["FormalChinese"] = "\u6B63\u5F0F";
    PlanCategoryEnum["DemoChinese"] = "\u6F14\u793A";
})(PlanCategoryEnum || (PlanCategoryEnum = {}));
var PlanCategoryEnumChinese;
(function (PlanCategoryEnumChinese) {
    PlanCategoryEnumChinese["Formal"] = "\u6B63\u5F0F";
    PlanCategoryEnumChinese["Demo"] = "\u6F14\u793A";
})(PlanCategoryEnumChinese || (PlanCategoryEnumChinese = {}));
var PlanStateEnum;
(function (PlanStateEnum) {
    PlanStateEnum["UnExecuted"] = "UnExecuted";
    PlanStateEnum["Executing"] = "Executing";
    PlanStateEnum["Stopped"] = "Stopped";
    PlanStateEnum["Completed"] = "Completed";
    PlanStateEnum["UnExecutedChinese"] = "\u672A\u6267\u884C";
    PlanStateEnum["ExecutingChinese"] = "\u6267\u884C\u4E2D";
    PlanStateEnum["StoppedChinese"] = "\u5DF2\u505C\u6B62";
    PlanStateEnum["CompletedChinese"] = "\u5DF2\u5B8C\u6210";
})(PlanStateEnum || (PlanStateEnum = {}));
var PlanStateEnumChinese;
(function (PlanStateEnumChinese) {
    PlanStateEnumChinese["UnExecuted"] = "\u672A\u6267\u884C";
    PlanStateEnumChinese["Executing"] = "\u6267\u884C\u4E2D";
    PlanStateEnumChinese["Stopped"] = "\u5DF2\u505C\u6B62";
    PlanStateEnumChinese["Completed"] = "\u5DF2\u5B8C\u6210";
})(PlanStateEnumChinese || (PlanStateEnumChinese = {}));
var PlanOperationEnum;
(function (PlanOperationEnum) {
    PlanOperationEnum["EXECUTE"] = "EXECUTE";
    PlanOperationEnum["STOP"] = "STOP";
    PlanOperationEnum["SAVE"] = "SAVE";
    PlanOperationEnum["EDIT"] = "EDIT";
    PlanOperationEnum["PLANNING"] = "PLANNING";
    PlanOperationEnum["COMPLETE"] = "COMPLETE";
})(PlanOperationEnum || (PlanOperationEnum = {}));



/***/ }),

/***/ "./src/app/manage/plan/models/task.enum.ts":
/*!*************************************************!*\
  !*** ./src/app/manage/plan/models/task.enum.ts ***!
  \*************************************************/
/*! exports provided: TaskEnum */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskEnum", function() { return TaskEnum; });
/**
 * Created by wujiahui on 2018/12/20.
 */
var TaskEnum;
(function (TaskEnum) {
    TaskEnum["ToDo"] = "ToDo";
    TaskEnum["Going"] = "Going";
    TaskEnum["Collecting"] = "Collecting";
    TaskEnum["Delay"] = "Delay";
    TaskEnum["Skipped"] = "Skipped";
    TaskEnum["Completed"] = "Completed";
    TaskEnum["ToDoChinese"] = "\u5F85\u6536\u96C6";
    TaskEnum["GoingChinese"] = "\u6B63\u5728\u524D\u5F80";
    TaskEnum["CollectingChinese"] = "\u6536\u96C6\u4E2D";
    TaskEnum["DelayChinese"] = "\u6302\u8D77";
    TaskEnum["SkippedChinese"] = "\u8DF3\u8FC7";
    TaskEnum["CompletedChinese"] = "\u5B8C\u6210\u6536\u96C6";
})(TaskEnum || (TaskEnum = {}));



/***/ }),

/***/ "./src/app/manage/plan/plan.service.ts":
/*!*********************************************!*\
  !*** ./src/app/manage/plan/plan.service.ts ***!
  \*********************************************/
/*! exports provided: PlanService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanService", function() { return PlanService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/index */ "./node_modules/rxjs/index.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(rxjs_index__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rebirth_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rebirth-http */ "./node_modules/rebirth-http/fesm5/rebirth-http.js");
/* harmony import */ var _shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/models/page/page-req.model */ "./src/app/shared/models/page/page-req.model.ts");
/* harmony import */ var _models_plan_req_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./models/plan-req.model */ "./src/app/manage/plan/models/plan-req.model.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");










var PlanService = /** @class */ /*@__PURE__*/ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(PlanService, _super);
    function PlanService(http) {
        return _super.call(this, http) || this;
    }
    PlanService.prototype.getPlanList = function (page, params) {
        return null;
    };
    /**
     * 新建方案时: 不必传入id
     * 复制方案时: 需传入源方案id
     * @param planReq
     * @param copyPlanId
     * @returns {null}
     */
    PlanService.prototype.addPlan = function (planReq, copyPlanId) {
        return null;
    };
    PlanService.prototype.delPlan = function (id) {
        return null;
    };
    PlanService.prototype.getRouteList = function (name, planId, planIds, plateNumber) {
        return null;
    };
    PlanService.prototype.operatingPlan = function (id, operate) {
        return null;
    };
    PlanService.prototype.getPlanReport = function (id) {
        return null;
    };
    PlanService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_5__["defineInjectable"]({ factory: function PlanService_Factory() { return new PlanService(_angular_core__WEBPACK_IMPORTED_MODULE_5__["inject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"])); }, token: PlanService, providedIn: "root" });
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/plans'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('page')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('params')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_3__["PageReq"], Object]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], PlanService.prototype, "getPlanList", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["POST"])('/plans'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Body"]), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('copyPlanId')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_models_plan_req_model__WEBPACK_IMPORTED_MODULE_4__["PlanReq"], String]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", void 0)
    ], PlanService.prototype, "addPlan", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["DELETE"])('/plans/:id'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], PlanService.prototype, "delPlan", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/routes'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('name')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('planId')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(2, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('planIds')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(3, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('plateNumber')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [String, Number, Array, String]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], PlanService.prototype, "getRouteList", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["POST"])('/plans/:id/operations'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('operate')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number, String]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], PlanService.prototype, "operatingPlan", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/reports/plans/:id'),
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RequestOptions"])({
            responseType: 'blob'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], PlanService.prototype, "getPlanReport", null);
    return PlanService;
}(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RebirthHttp"]));




/***/ }),

/***/ "./src/app/shared/pipes/plan/plan.pipe.ts":
/*!************************************************!*\
  !*** ./src/app/shared/pipes/plan/plan.pipe.ts ***!
  \************************************************/
/*! exports provided: TaskStateToChinesePipe, PlanStateToChinesePipe, PlanCategoryToChinesePipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskStateToChinesePipe", function() { return TaskStateToChinesePipe; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanStateToChinesePipe", function() { return PlanStateToChinesePipe; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PlanCategoryToChinesePipe", function() { return PlanCategoryToChinesePipe; });
/* harmony import */ var _manage_plan_models_task_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../manage/plan/models/task.enum */ "./src/app/manage/plan/models/task.enum.ts");
/* harmony import */ var _manage_plan_models_plan_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../manage/plan/models/plan.enum */ "./src/app/manage/plan/models/plan.enum.ts");


var TaskStateToChinesePipe = /** @class */ /*@__PURE__*/ (function () {
    function TaskStateToChinesePipe() {
    }
    TaskStateToChinesePipe.prototype.transform = function (value) {
        var key = value + 'Chinese';
        return _manage_plan_models_task_enum__WEBPACK_IMPORTED_MODULE_0__["TaskEnum"][key];
    };
    return TaskStateToChinesePipe;
}());

var PlanStateToChinesePipe = /** @class */ /*@__PURE__*/ (function () {
    function PlanStateToChinesePipe() {
    }
    PlanStateToChinesePipe.prototype.transform = function (value) {
        var key = value + 'Chinese';
        return _manage_plan_models_plan_enum__WEBPACK_IMPORTED_MODULE_1__["PlanStateEnum"][key];
    };
    return PlanStateToChinesePipe;
}());

var PlanCategoryToChinesePipe = /** @class */ /*@__PURE__*/ (function () {
    function PlanCategoryToChinesePipe() {
    }
    PlanCategoryToChinesePipe.prototype.transform = function (value) {
        var key = value + 'Chinese';
        return _manage_plan_models_plan_enum__WEBPACK_IMPORTED_MODULE_1__["PlanCategoryEnum"][key];
    };
    return PlanCategoryToChinesePipe;
}());




/***/ })

}]);
//# sourceMappingURL=2.5a8eebd969b90cc2b8c0.js.map