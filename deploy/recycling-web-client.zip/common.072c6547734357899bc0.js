(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "./src/app/manage/base/staff-info/staff-info.service.ts":
/*!**************************************************************!*\
  !*** ./src/app/manage/base/staff-info/staff-info.service.ts ***!
  \**************************************************************/
/*! exports provided: StaffInfoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StaffInfoService", function() { return StaffInfoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/index */ "./node_modules/rxjs/index.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(rxjs_index__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rebirth_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rebirth-http */ "./node_modules/rebirth-http/fesm5/rebirth-http.js");
/* harmony import */ var _shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/models/page/page-req.model */ "./src/app/shared/models/page/page-req.model.ts");
/* harmony import */ var _staff_req_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./staff-req.model */ "./src/app/manage/base/staff-info/staff-req.model.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");










var StaffInfoService = /** @class */ /*@__PURE__*/ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(StaffInfoService, _super);
    function StaffInfoService(http) {
        return _super.call(this, http) || this;
    }
    StaffInfoService.prototype.getStaffList = function (pageReq, params) {
        return null;
    };
    StaffInfoService.prototype.addStaff = function (staff) {
        return null;
    };
    StaffInfoService.prototype.updateStaff = function (id, staff) {
        return null;
    };
    StaffInfoService.prototype.delStaff = function (id) {
        return null;
    };
    StaffInfoService.prototype.getStaffReport = function (id) {
        return null;
    };
    StaffInfoService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_5__["defineInjectable"]({ factory: function StaffInfoService_Factory() { return new StaffInfoService(_angular_core__WEBPACK_IMPORTED_MODULE_5__["inject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"])); }, token: StaffInfoService, providedIn: "root" });
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/employees'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('page')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('params')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_3__["PageReq"], Object]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", Object)
    ], StaffInfoService.prototype, "getStaffList", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["POST"])('/employees'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Body"]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_staff_req_model__WEBPACK_IMPORTED_MODULE_4__["StaffReq"]]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], StaffInfoService.prototype, "addStaff", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["PUT"])('/employees/:id'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')), Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Body"]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number, _staff_req_model__WEBPACK_IMPORTED_MODULE_4__["StaffReq"]]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], StaffInfoService.prototype, "updateStaff", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["DELETE"])('/employees/:id'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], StaffInfoService.prototype, "delStaff", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/reports/employees/:id'),
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RequestOptions"])({
            responseType: 'blob'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], StaffInfoService.prototype, "getStaffReport", null);
    return StaffInfoService;
}(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RebirthHttp"]));




/***/ }),

/***/ "./src/app/manage/base/staff-info/staff-req.model.ts":
/*!***********************************************************!*\
  !*** ./src/app/manage/base/staff-info/staff-req.model.ts ***!
  \***********************************************************/
/*! exports provided: StaffReq, AddressReq, ContactInfoReq */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StaffReq", function() { return StaffReq; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddressReq", function() { return AddressReq; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactInfoReq", function() { return ContactInfoReq; });
/**
 * Created by wujiahui on 2018/11/13.
 */
var StaffReq = /** @class */ /*@__PURE__*/ (function () {
    function StaffReq() {
        this.entryTime = null;
        this.identity = null;
        this.name = null;
        this.password = null;
        this.postId = null;
        this.roles = null;
        this.sex = null;
        this.username = null;
    }
    return StaffReq;
}());

var AddressReq = /** @class */ /*@__PURE__*/ (function () {
    function AddressReq(req) {
        this.city = null;
        this.cityCode = null;
        this.county = null;
        this.countyCode = null;
        this.detailedAddress = null;
        this.province = null;
        this.provinceCode = null;
        this.street = null;
        this.streetCode = null;
        this.city = req.city || null;
        this.cityCode = req.cityCode || null;
        this.county = req.county || null;
        this.countyCode = req.countyCode || null;
        this.detailedAddress = req.detailedAddress || null;
        this.province = req.province || null;
        this.provinceCode = req.provinceCode || null;
        this.street = req.street || null;
        this.streetCode = req.streetCode || null;
    }
    return AddressReq;
}());

var ContactInfoReq = /** @class */ /*@__PURE__*/ (function () {
    function ContactInfoReq(req) {
        this.email = null;
        this.emergencyContact = null;
        this.emergencyContactPhone = null;
        this.landlinePhone = null;
        this.mobilePhone = null;
        this.email = req.email || null;
        this.emergencyContact = req.emergencyContact || null;
        this.emergencyContactPhone = req.emergencyContactPhone || null;
        this.landlinePhone = req.landlinePhone || null;
        this.mobilePhone = req.mobilePhone || null;
    }
    return ContactInfoReq;
}());




/***/ }),

/***/ "./src/app/manage/base/vehicle-info/models/vehicle-category.enum.ts":
/*!**************************************************************************!*\
  !*** ./src/app/manage/base/vehicle-info/models/vehicle-category.enum.ts ***!
  \**************************************************************************/
/*! exports provided: VehicleCategoryEnum */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VehicleCategoryEnum", function() { return VehicleCategoryEnum; });
/**
 * Created by wujiahui on 2018/12/11.
 */
var VehicleCategoryEnum;
(function (VehicleCategoryEnum) {
    VehicleCategoryEnum["food5"] = "5\u5428\u9910\u53A8\u8F66";
    VehicleCategoryEnum[VehicleCategoryEnum["food5Index"] = 1] = "food5Index";
    VehicleCategoryEnum["food8"] = "8\u5428\u9910\u53A8\u8F66";
    VehicleCategoryEnum[VehicleCategoryEnum["food8Index"] = 2] = "food8Index";
    VehicleCategoryEnum["oil1"] = "1\u5428\u6CB9\u8102\u8F66";
    VehicleCategoryEnum[VehicleCategoryEnum["oil1Index"] = 3] = "oil1Index";
})(VehicleCategoryEnum || (VehicleCategoryEnum = {}));



/***/ }),

/***/ "./src/app/manage/base/vehicle-info/vehicle-info.service.ts":
/*!******************************************************************!*\
  !*** ./src/app/manage/base/vehicle-info/vehicle-info.service.ts ***!
  \******************************************************************/
/*! exports provided: VehicleInfoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VehicleInfoService", function() { return VehicleInfoService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/index */ "./node_modules/rxjs/index.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(rxjs_index__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rebirth_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rebirth-http */ "./node_modules/rebirth-http/fesm5/rebirth-http.js");
/* harmony import */ var _shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../shared/models/page/page-req.model */ "./src/app/shared/models/page/page-req.model.ts");
/* harmony import */ var _vehicle_req_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./vehicle-req.model */ "./src/app/manage/base/vehicle-info/vehicle-req.model.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");










var VehicleInfoService = /** @class */ /*@__PURE__*/ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(VehicleInfoService, _super);
    function VehicleInfoService(http) {
        return _super.call(this, http) || this;
    }
    VehicleInfoService.prototype.mockListData = function () {
        return null;
    };
    VehicleInfoService.prototype.getVehicleList = function (page, params) {
        // TODO
        return null;
    };
    VehicleInfoService.prototype.addVehicle = function (vehicle) {
        return null;
    };
    /**
     * 更新车辆
     * @returns {null}
     */
    VehicleInfoService.prototype.updateVehicle = function (vehicle, id) {
        return null;
    };
    /**
     * 删除车辆
     * @returns {null}
     */
    VehicleInfoService.prototype.delCustomer = function (id) {
        return null;
    };
    VehicleInfoService.prototype.getVehicleReport = function (id) {
        return null;
    };
    VehicleInfoService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_5__["defineInjectable"]({ factory: function VehicleInfoService_Factory() { return new VehicleInfoService(_angular_core__WEBPACK_IMPORTED_MODULE_5__["inject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"])); }, token: VehicleInfoService, providedIn: "root" });
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/vehicles'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('page')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('params')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_3__["PageReq"], Object]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], VehicleInfoService.prototype, "getVehicleList", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["POST"])('/vehicles'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Body"]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_vehicle_req_model__WEBPACK_IMPORTED_MODULE_4__["VehicleReq"]]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], VehicleInfoService.prototype, "addVehicle", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["PUT"])('/vehicles/:id'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Body"]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_vehicle_req_model__WEBPACK_IMPORTED_MODULE_4__["VehicleReq"], Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], VehicleInfoService.prototype, "updateVehicle", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["DELETE"])('/vehicles/:id'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], VehicleInfoService.prototype, "delCustomer", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/reports/vehicles/:id'),
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RequestOptions"])({
            responseType: 'blob'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], VehicleInfoService.prototype, "getVehicleReport", null);
    return VehicleInfoService;
}(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RebirthHttp"]));




/***/ }),

/***/ "./src/app/manage/base/vehicle-info/vehicle-req.model.ts":
/*!***************************************************************!*\
  !*** ./src/app/manage/base/vehicle-info/vehicle-req.model.ts ***!
  \***************************************************************/
/*! exports provided: VehicleReq, BusinessLineReq */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VehicleReq", function() { return VehicleReq; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BusinessLineReq", function() { return BusinessLineReq; });
/**
 * Created by wujiahui on 2018/11/12.
 */
var VehicleReq = /** @class */ /*@__PURE__*/ (function () {
    function VehicleReq() {
        this.boxId = null;
        this.buyDate = null;
        this.engineModel = null;
        this.idNumber = null;
    }
    return VehicleReq;
}());

var BusinessLineReq = /** @class */ /*@__PURE__*/ (function () {
    function BusinessLineReq() {
        // areaCode: string = null;
        this.planBackTime = null;
        this.planDepartureTime = null;
        this.test = null;
        this.typeId = null; // 1-5吨餐厨车 = null; 2-8吨餐厨车 = null; 3-1吨油脂车
    }
    return BusinessLineReq;
}());




/***/ }),

/***/ "./src/app/manage/history/history.service.ts":
/*!***************************************************!*\
  !*** ./src/app/manage/history/history.service.ts ***!
  \***************************************************/
/*! exports provided: HistoryService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HistoryService", function() { return HistoryService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/index */ "./node_modules/rxjs/index.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(rxjs_index__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rebirth_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rebirth-http */ "./node_modules/rebirth-http/fesm5/rebirth-http.js");
/* harmony import */ var _shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/models/page/page-req.model */ "./src/app/shared/models/page/page-req.model.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");









var HistoryService = /** @class */ /*@__PURE__*/ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(HistoryService, _super);
    function HistoryService(http) {
        return _super.call(this, http) || this;
    }
    HistoryService.prototype.getLocations = function (vehicleId, startTime, endTime) {
        return null;
    };
    HistoryService.prototype.updateCustomerLocation = function (id, location) {
        return null;
    };
    HistoryService.prototype.getTaskList = function (id) {
        return null;
    };
    HistoryService.prototype.getWeighBridgesList = function (page, params) {
        return null;
    };
    HistoryService.prototype.getWeighBridgesReport = function (month) {
        return null;
    };
    HistoryService.ngInjectableDef = _angular_core__WEBPACK_IMPORTED_MODULE_4__["defineInjectable"]({ factory: function HistoryService_Factory() { return new HistoryService(_angular_core__WEBPACK_IMPORTED_MODULE_4__["inject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"])); }, token: HistoryService, providedIn: "root" });
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/locations/:vehicleId/:startTime/:endTime'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('vehicleId')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('startTime')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(2, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('endTime')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number, Number, Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], HistoryService.prototype, "getLocations", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["PUT"])('/customers/:id/location'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Body"]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number, Object]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], HistoryService.prototype, "updateCustomerLocation", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/routes/:id/tasks'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('id')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [Number]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], HistoryService.prototype, "getTaskList", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/weighBridges'),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('page')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Query"])('params')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [_shared_models_page_page_req_model__WEBPACK_IMPORTED_MODULE_3__["PageReq"], Object]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], HistoryService.prototype, "getWeighBridgesList", null);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["GET"])('/weighBridges/export/:month'),
        Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RequestOptions"])({
            responseType: 'blob'
        }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["Path"])('month')),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:type", Function),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [String]),
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:returntype", rxjs_index__WEBPACK_IMPORTED_MODULE_1__["Observable"])
    ], HistoryService.prototype, "getWeighBridgesReport", null);
    return HistoryService;
}(rebirth_http__WEBPACK_IMPORTED_MODULE_2__["RebirthHttp"]));




/***/ }),

/***/ "./src/app/manage/plan/models/task.model.ts":
/*!**************************************************!*\
  !*** ./src/app/manage/plan/models/task.model.ts ***!
  \**************************************************/
/*! exports provided: TaskState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaskState", function() { return TaskState; });
/**
 * Created by wujiahui on 2019/1/2.
 */
var TaskState;
(function (TaskState) {
    TaskState["ToDo"] = "ToDo";
    TaskState["Going"] = "Going";
    TaskState["Collecting"] = "Collecting";
    TaskState["Delay"] = "Delay";
    TaskState["Skipped"] = "Skipped";
    TaskState["Completed"] = "Completed";
})(TaskState || (TaskState = {}));



/***/ }),

/***/ "./src/app/shared/components/amap/adriving.component.ngfactory.js":
/*!************************************************************************!*\
  !*** ./src/app/shared/components/amap/adriving.component.ngfactory.js ***!
  \************************************************************************/
/*! exports provided: RenderType_AdrivingComponent, View_AdrivingComponent_0, View_AdrivingComponent_Host_0, AdrivingComponentNgFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RenderType_AdrivingComponent", function() { return RenderType_AdrivingComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_AdrivingComponent_0", function() { return View_AdrivingComponent_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "View_AdrivingComponent_Host_0", function() { return View_AdrivingComponent_Host_0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdrivingComponentNgFactory", function() { return AdrivingComponentNgFactory; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _adriving_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./adriving.component */ "./src/app/shared/components/amap/adriving.component.ts");
/* harmony import */ var _services_map_map_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/map/map.service */ "./src/app/shared/services/map/map.service.ts");
/**
 * @fileoverview This file was generated by the Angular template compiler. Do not edit.
 *
 * @suppress {suspiciousCode,uselessCode,missingProperties,missingOverride,checkTypes}
 * tslint:disable
 */



var styles_AdrivingComponent = [];
var RenderType_AdrivingComponent = /*@__PURE__*/ /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵcrt"]({ encapsulation: 2, styles: styles_AdrivingComponent, data: {} });

function View_AdrivingComponent_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵeld"](0, 0, null, null, 0, "div", [["class", "driving"]], null, null, null, null, null))], null, null); }
function View_AdrivingComponent_Host_0(_l) { return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵeld"](0, 0, null, null, 1, "app-adriving", [], null, null, null, View_AdrivingComponent_0, RenderType_AdrivingComponent)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵdid"](1, 770048, null, 0, _adriving_component__WEBPACK_IMPORTED_MODULE_1__["AdrivingComponent"], [_services_map_map_service__WEBPACK_IMPORTED_MODULE_2__["MapService"]], null, null)], function (_ck, _v) { _ck(_v, 1, 0); }, null); }
var AdrivingComponentNgFactory = /*@__PURE__*/ /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵccf"]("app-adriving", _adriving_component__WEBPACK_IMPORTED_MODULE_1__["AdrivingComponent"], View_AdrivingComponent_Host_0, { outlineColor: "outlineColor" }, { drawWaypointsEvent: "drawWaypointsEvent", clearEvent: "clearEvent" }, []);




/***/ }),

/***/ "./src/app/shared/components/amap/adriving.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/shared/components/amap/adriving.component.ts ***!
  \**************************************************************/
/*! exports provided: AdrivingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdrivingComponent", function() { return AdrivingComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_map_driving_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/map/driving.model */ "./src/app/shared/services/map/driving.model.ts");


var AdrivingComponent = /** @class */ /*@__PURE__*/ (function () {
    function AdrivingComponent(mapService) {
        this.mapService = mapService;
        this.drawWaypointsEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.clearEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    AdrivingComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._complete$ = this.mapService.mapListener$.subscribe(function () {
            _this.init();
        });
    };
    AdrivingComponent.prototype.ngOnChanges = function () {
        if (this.mapService.map) {
            this.init();
        }
    };
    AdrivingComponent.prototype.ngOnDestroy = function () {
        if (this._complete$) {
            this._complete$.unsubscribe();
        }
    };
    AdrivingComponent.prototype.init = function () {
        this.create();
        this.drawWaypointsEvent.emit(this.drawWaypoints.bind(this));
        this.clearEvent.emit(this.clear.bind(this));
    };
    AdrivingComponent.prototype.create = function () {
        var drivingModel = new _services_map_driving_model__WEBPACK_IMPORTED_MODULE_1__["Driving"]({
            map: this.mapService.map,
            hideMarkers: true,
            outlineColor: this.outlineColor,
        });
        this._drivingService = this.mapService.createDriving(drivingModel);
    };
    /**
     * 根据任务列表数据直接在地图上画出行车路径
     * 如果数据是有5个点，会由起点一直画到终点（包括起点终点之间的途经点）
     */
    AdrivingComponent.prototype.drawWaypoints = function (start, lngLatList) {
        var converLngLat = this.mapService.lngLat;
        var firstModel = lngLatList[0];
        var lastLenght = lngLatList.length - 1;
        var lastModel = lngLatList[lastLenght];
        if (firstModel) {
            var waypoints_1 = [];
            lngLatList.forEach(function (model, index) {
                if (index === lastLenght) {
                    return;
                }
                waypoints_1.push(converLngLat([model.lng, model.lat]));
            });
            this._drivingService.search(converLngLat([start.lng, start.lat]), converLngLat([lastModel.lng, lastModel.lat]), { waypoints: waypoints_1 });
        }
    };
    AdrivingComponent.prototype.clear = function () {
        this._drivingService.clear();
    };
    return AdrivingComponent;
}());




/***/ }),

/***/ "./src/app/shared/services/map/driving.model.ts":
/*!******************************************************!*\
  !*** ./src/app/shared/services/map/driving.model.ts ***!
  \******************************************************/
/*! exports provided: Driving, DrivingPolicy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Driving", function() { return Driving; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DrivingPolicy", function() { return DrivingPolicy; });
var Driving = /** @class */ /*@__PURE__*/ (function () {
    function Driving(obj) {
        /* tslint:disable-next-line */
        for (var k in obj) {
            this[k] = obj[k];
        }
    }
    Driving.prototype.search = function (start, end, opts) { };
    Driving.prototype.clear = function () { };
    return Driving;
}());

var DrivingPolicy;
(function (DrivingPolicy) {
    DrivingPolicy["LEAST_TIME"] = "LEAST_TIME";
    DrivingPolicy["LEAST_FEE"] = "LEAST_FEE";
    DrivingPolicy["LEAST_DISTANCE"] = "LEAST_DISTANCE";
    DrivingPolicy["REAL_TRAFFIC"] = "REAL_TRAFFIC"; // 考虑实时路况
})(DrivingPolicy || (DrivingPolicy = {}));



/***/ }),

/***/ "./src/app/shared/utils/date-utils.ts":
/*!********************************************!*\
  !*** ./src/app/shared/utils/date-utils.ts ***!
  \********************************************/
/*! exports provided: DateUtil */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DateUtil", function() { return DateUtil; });
/**
 * Created by wujiahui on 2018/11/8.
 */
var DateUtil = /** @class */ /*@__PURE__*/ (function () {
    function DateUtil() {
    }
    /**
     * 格式化日期
     * @param date
     * @param fmt
     * @returns {string}
     */
    DateUtil.dateFormat = function (date, fmt) {
        var o = {
            'M+': date.getMonth() + 1,
            'd+': date.getDate(),
            'h+': date.getHours(),
            'm+': date.getMinutes(),
            's+': date.getSeconds(),
            'q+': Math.floor((date.getMonth() + 3) / 3),
            'S': date.getMilliseconds() // 毫秒
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp('(' + k + ')').test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)));
            }
        }
        return fmt;
    };
    return DateUtil;
}());




/***/ })

}]);
//# sourceMappingURL=common.072c6547734357899bc0.js.map